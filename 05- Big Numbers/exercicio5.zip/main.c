#include "list.h"

int main() {
    int qtdOp = 0;
    scanf(" %d", &qtdOp);
    realizar_operacoes(qtdOp);

    return 0;
}