#ifndef UTIL_H
#define UTIL_H

typedef char elem;
typedef struct node_st NO;
typedef int boolean;

enum teste {FALSE, TRUE};

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *read_word();

#endif